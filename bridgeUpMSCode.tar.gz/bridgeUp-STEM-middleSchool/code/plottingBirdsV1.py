#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #4:  draws bird observations, in versions
#    Version 1: draws 5 birds observed

import turtle            #Loads the turtle graphics commands

win = turtle.Screen()    #Stores the graphics window in variable, win
win.setworldcoordinates(-1,-1,21,21)    #Resize the window to make drawing
                         #easier.  Lower left is (-1,-1) and upper right is (21,21).
                         #Windows are square, so, good if global coordinates are
                         #similarly proportioned.

birdy = turtle.Turtle()  #Constructs a turtle & stores in variable, birdy             
birdy.turtlesize(2,2)    #Makes birdy twice as big
birdy.shape("turtle")    #Makes birdy turtle shaped
birdy.speed(10)          #Speeds up drawing
birdy.up()               #Lift pen, since not needed for stamping

#Points are taken from student's lab notes of where the students observed
#    using the grid to make determine (x,y) values

### Note:  We have not taught lists yet, so, this should be enter each separately.
###  If students say there must be an easier way, say yes, there is, and we'll
###  cover how to group information together to use in loops later.

#Draw first bird observed:
birdy.goto(4,8)
birdy.stamp()

#Draw second bird observed:
birdy.goto(2,8)
birdy.stamp()

#Draw third bird observed:
birdy.goto(20,0.5)
birdy.stamp()

#Draw fourth bird observed:
birdy.goto(2,15)
birdy.stamp()

#Draw fifth bird observed:
birdy.goto(10,10)
birdy.stamp()

#Close window when clicked:
win.exitonclick()
