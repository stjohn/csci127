#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #3:  draws a simple 15x20 classroom, in versions
#    Version 1: sets up turtle and draws classroom walls
#    Version 2: adds in tables to room

import turtle            #Loads the turtle graphics commands


win = turtle.Screen()    #Stores the graphics window in variable, win
win.setworldcoordinates(-1,-1,21,21)    #Resize the window to make drawing
                         #easier.  Lower left is (-1,-1) and upper right is (21,21).
                         #Windows are square, so, good if global coordinates are
                         #similarly proportioned.

drew = turtle.Turtle()   #Constructs a turtle & stores in variable, drew             
drew.pensize(5)          #Makes drew's lines wider
drew.speed(10)           #Speeds up drawing 

#Draw classroom walls:
drew.forward(15)         #South wall
drew.left(90)            #Turn north to draw east wall
drew.forward(20)         #East wall
drew.left(90)            #Turn west to draw north wall
drew.forward(15)         #North wall
drew.left(90)            #Turn south to draw west wall
drew.forward(17)         #West wall, with opening for door

#Draw rectangle to represent table at front of room:
drew.up()                #Lift drawing pen before moving to table location
drew.goto(4,3)           #Move turtle to (10,2)
drew.down()              #Put pen down to draw
drew.forward(2)          
drew.left(90)
drew.forward(8)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(8)
drew.left(90)

#Draw rectangles to represent additional tables in room:
drew.up()                
drew.goto(2,7)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(9,7)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(2,11)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(9,11)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(2,15)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(9,15)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(2,19)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)

drew.up()                
drew.goto(9,19)           
drew.down()              
drew.forward(2)          
drew.left(90)
drew.forward(4)
drew.left(90)
drew.forward(2)
drew.left(90)
drew.forward(4)
drew.left(90)
