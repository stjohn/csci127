#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #7:  counts number of birds in noisy environments

infile = open("noisyBirds.txt")

numNoisy = 0                  #Set the accumulator variable to 0

for line in infile:           #Repeat for each line of the file
     x,y,noise = eval(line)   #Get the numbers from file
     if noise >= 70:
          numNoisy = numNoisy + 1  #Increase the numNoisy
          print "numNoisy is now", numNoisy #Print the current total
     else:
          print "quiet for this bird"

print "The number of birds in noisy places is", numNoisy
                              #Prints the final running total

