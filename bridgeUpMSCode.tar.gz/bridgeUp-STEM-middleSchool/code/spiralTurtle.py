#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #1:  modify first program to go forward 10*i 

import turtle            #Loads the turtle graphics commands

teddy = turtle.Turtle()  #Constructs a turtle & stores in variable, teddy

for i in range(50):      #Repeat the indented statments 50 times
     teddy.forward(10*i) #Moves the turtle teddy forward 10*i steps
     teddy.right(90)     #Turns teddy right 90 degrees
