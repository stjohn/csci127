#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #7:  counts number of birds in quiet environments

infile = open("noisyBirds.txt")

numQuiet = 0                  #Set the accumulator variable to 0

for line in infile:           #Repeat for each line of the file
     x,y,noise = eval(line)   #Get the numbers from file
     if noise <= 70:
          numQuiet = numQuiet + 1  #Increase the numNoisy
          print "numQuiet is now", numQuiet #Print the current total
     else:
          print "loud for this bird"

print "The number of birds in quiet places is", numQuiet
                              #Prints the final running total

