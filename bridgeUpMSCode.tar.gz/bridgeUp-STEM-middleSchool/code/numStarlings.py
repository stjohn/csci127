#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #7:  counts number of starlings

infile = open("namedBirds.txt")

numStarlings = 0              #Set the accumulator variable to 0

for line in infile:           #Repeat for each line of the file
     x,y,noise,species = eval(line)   #Get the numbers from file
     if species == 3:
          numStarlings = numStarlings + 1  #Increase the numNoisy
          print "numStarlings is now", numStarlings #Print the current total
     else:
          print "loud for this bird"

print "The number of starlings is", numStarlings
                              #Prints the final running total

