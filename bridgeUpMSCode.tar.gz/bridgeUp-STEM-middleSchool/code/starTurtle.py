#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #1:  modify first program to draw a 5-pointed star

import turtle            #Loads the turtle graphics commands

teddy = turtle.Turtle()  #Constructs a turtle & stores in variable, teddy

for i in range(5):       #Repeat the indented statments 5 times
     teddy.forward(100)  #Moves the turtle teddy forward 100 steps
     teddy.right(720/5)  #teddy makes 2 full rotations, divided evenly into 5 turns
