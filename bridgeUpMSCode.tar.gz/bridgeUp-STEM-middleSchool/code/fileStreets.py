#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #5:  draws streets

import turtle            #Loads the turtle graphics commands

win = turtle.Screen()    #Stores the graphics window in variable, win
win.setworldcoordinates(-1,-1,21,21)    #Resize the window to make drawing
                         #easier.  Lower left is (-1,-1) and upper right is (21,21).
                         #Windows are square, so, good if global coordinates are
                         #similarly proportioned.

birdy = turtle.Turtle()  #Constructs a turtle & stores in variable, birdy             
birdy.turtlesize(2,2)    #Makes birdy twice as big
birdy.shape("turtle")    #Makes birdy turtle shaped
birdy.speed(10)          #Speeds up drawing
birdy.up()               #Lift pen, since not needed for stamping
birdy.pensize(4)         #Make streets easier to see

#Points are taken from student's lab notes of where the students observed
#    using the grid to make determine (x,y) values

infile = open("streets.txt", "r")#Open file for reading
for line in infile:      #For each line in the file
     x1,y1,x2,y2 = eval(line)    #Turn the line from words to numbers and
                         #store in x1, y1, x2, y2
     birdy.goto(x1,y1)   #Move birdy to beginning of street (x1,y1)
     birdy.down()        #Put pen down to draw
     birdy.goto(x2,y2)   #Move birdy to end of street (x2,y2)
     birdy.up()          #Lift up pen
     
infile.close()           #Closes file

win.exitonclick()        #Close window when clicked
