#AMNH BridgeUp: STEM Middle School Program
#Sample program for Session #1

import turtle            #Loads the turtle graphics commands

teddy = turtle.Turtle()  #Constructs a turtle & stores in variable, teddy

for i in range(4):       #Repeat the indented statments 4 times
     teddy.forward(100)  #Moves the turtle teddy forward 100 steps
     teddy.right(90)     #Turns teddy right 90 degrees
