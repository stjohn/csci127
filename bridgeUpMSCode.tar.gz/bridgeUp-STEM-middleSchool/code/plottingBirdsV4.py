#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #4:  draws bird observations, in versions
#    Version 1: draws 5 birds observed
#    Version 2: adds in 4 streets
#    Version 3: colors birds by species
#    Version 4: add in street names

import turtle            #Loads the turtle graphics commands

win = turtle.Screen()    #Stores the graphics window in variable, win
win.setworldcoordinates(-1,-1,21,21)    #Resize the window to make drawing
                         #easier.  Lower left is (-1,-1) and upper right is (21,21).
                         #Windows are square, so, good if global coordinates are
                         #similarly proportioned.

birdy = turtle.Turtle()  #Constructs a turtle & stores in variable, birdy             
birdy.turtlesize(2,2)    #Makes birdy twice as big
birdy.shape("turtle")    #Makes birdy turtle shaped
birdy.speed(10)          #Speeds up drawing
birdy.up()               #Lift pen, since not needed for stamping

#Points are taken from student's lab notes of where the students observed
#    using the grid to make determine (x,y) values

### Note:  We have not taught lists yet, so, this should be enter each separately.
###  If students say there must be an easier way, say yes, there is, and we'll
###  cover how to group information together to use in loops later.

#Draw first bird observed:
birdy.goto(4,8)
birdy.color("blue")      #Make blue for blue jays
birdy.stamp()

#Draw second bird observed:
birdy.goto(2,8)
birdy.color("gray")      #Make gray for starlings
birdy.stamp()

#Draw third bird observed:
birdy.goto(20,0.5)
birdy.color("blue")      #Make blue for blue jay
birdy.stamp()

#Draw fourth bird observed:
birdy.goto(2,15)
birdy.color("red")       #Make red for cardinal
birdy.stamp()

#Draw fifth bird observed:
birdy.goto(10,10)
birdy.color("green")     #Make green for mallard
birdy.stamp()

birdy.color("black")     #Turn pen back to black for streets

#Make pen larger to see the streets better:
birdy.pensize(4)


#Draw first street:
birdy.goto(5,0)
birdy.down()
birdy.goto(5,20)
birdy.up()
birdy.write("Columbus", font=("Arial", 12, "normal"))
#Can also have:  birdy.write("Columbus") but font is small

#Draw second street:
birdy.goto(0,9)
birdy.down()
birdy.goto(20,9)
birdy.up()
birdy.write("77th", font=("Arial", 12, "normal"))

#Draw third street:
birdy.goto(0,2)
birdy.down()
birdy.goto(20,2)
birdy.up()
birdy.write("76th", font=("Arial", 12, "normal"))

#Draw fourth street:
birdy.goto(0,15.5)
birdy.down()
birdy.goto(5,15.5)
birdy.up()
birdy.write("78th", font=("Arial", 12, "normal"))



birdy.goto(0,0)

#Close window when clicked:
win.exitonclick()

