#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #6:  calculates average from file

infile = open("noisyBirds.txt")

runningTotal = 0              #Set the accumulator variable to 0

for line in infile:           #Repear for each line of the file
     x,y,noise = eval(line)   #Get the numbers from file
     runningTotal = runningTotal + noise    #Add number to the runningTotal
     print "Running total is now", runningTotal #Print the current total

average = runningTotal/10.0
print "The total is", runningTotal #Prints the final running total
print "The average is", average    #Prints the average
