#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #1: write your name to the screen 50 times

for i in range(50):      #Repeat the indented statments 50 times
     print "Teddy Roosevelt"
