#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #8: draws from simplified JSON file

import turtle            #Loads the turtle graphics commands

win = turtle.Screen()    #Stores the graphics window in variable, win
win.setworldcoordinates(-100,20,-50,70)    #Resize the window to make drawing
                         #easier.  Lower left is (-1,-1) and upper right is (21,21).
                         #Windows are square, so, good if global coordinates are
                         #similarly proportioned.

linnea = turtle.Turtle() #Constructs a turtle & stores in variable, linnea             
linnea.turtlesize(2,2)   #Makes linnea twice as big
linnea.speed(10)         #Speeds up drawing
linnea.up()              #Lift pen before moving about

#Points are taken from student's lab notes of where the students observed
#    using the grid to make determine (x,y) values

infile = open("state.txt", "r")#Open file for reading
for line in infile:      #For each line in the file
     points = eval(line)
     linnea.goto(points[0][0],points[0][1])
     linnea.down()       #Put the pen to start drawing
     for p in points:
          linnea.goto(p[0],p[1])
     linnea.up()         #Lift the pen when you finish a continent
          
infile.close()           #Closes file
win.exitonclick()        #Close graphics window on mouse click
