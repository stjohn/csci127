#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #5:  draws bird observations, in versions
#    Version 1: draws 5 birds observed taking input from file
#    Version 2: splits species into files and draws each different colors

import turtle            #Loads the turtle graphics commands

win = turtle.Screen()    #Stores the graphics window in variable, win
win.setworldcoordinates(-1,-1,21,21)    #Resize the window to make drawing
                         #easier.  Lower left is (-1,-1) and upper right is (21,21).
                         #Windows are square, so, good if global coordinates are
                         #similarly proportioned.

birdy = turtle.Turtle()  #Constructs a turtle & stores in variable, birdy             
birdy.turtlesize(2,2)    #Makes birdy twice as big
birdy.shape("turtle")    #Makes birdy turtle shaped
birdy.speed(10)          #Speeds up drawing
birdy.up()               #Lift pen, since not needed for stamping

#Points are taken from student's lab notes of where the students observed
#    using the grid to make determine (x,y) values

infile = open("blueJays.txt", "r")#Open file for reading
birdy.color("blue")
for line in infile:      #For each line in the file
     x,y = eval(line)    #Turn the line from words to numbers and store in x & y
     birdy.goto(x,y)     #Move birdy to (x,y)
     birdy.stamp()       #Make a stamp
infile.close()           #Closes file

infile = open("starlings.txt", "r")#Open file for reading
birdy.color("gray")
for line in infile:      #For each line in the file
     x,y = eval(line)    #Turn the line from words to numbers and store in x & y
     birdy.goto(x,y)     #Move birdy to (x,y)
     birdy.stamp()       #Make a stamp
infile.close()           #Closes file

infile = open("cardinals.txt", "r")#Open file for reading
birdy.color("red")
for line in infile:      #For each line in the file
     x,y = eval(line)    #Turn the line from words to numbers and store in x & y
     birdy.goto(x,y)     #Move birdy to (x,y)
     birdy.stamp()       #Make a stamp
infile.close()           #Closes file

infile = open("mallards.txt", "r")#Open file for reading
birdy.color("green")
for line in infile:      #For each line in the file
     x,y = eval(line)    #Turn the line from words to numbers and store in x & y
     birdy.goto(x,y)     #Move birdy to (x,y)
     birdy.stamp()       #Make a stamp
infile.close()           #Closes file
win.exitonclick()        #Close window when clicked
