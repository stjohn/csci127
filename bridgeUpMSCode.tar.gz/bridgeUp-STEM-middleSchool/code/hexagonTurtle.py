#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #1:  modify first program to draw a hexagon

import turtle            #Loads the turtle graphics commands

teddy = turtle.Turtle()  #Constructs a turtle & stores in variable, teddy

for i in range(6):       #Repeat the indented statments 6 times
     teddy.forward(100)  #Moves the turtle teddy forward 100 steps
     teddy.right(360/6)  #Divides teddy's full rotation into 6 pieces
