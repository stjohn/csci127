#AMNH BridgeUp: STEM Middle School Program
#Sample solution for Session #6: calculates running total from user input

runningTotal = 0              #Set the accumulator variable to 0

for turn in range(10):        #Repeat 10 times
     number = input("Enter size: ")          #Gets number from user
     runningTotal = runningTotal + number    #Add number to the runningTotal
     print "Running total is now", runningTotal #Print the current total
     
print "The total is", runningTotal #Print the final running total
