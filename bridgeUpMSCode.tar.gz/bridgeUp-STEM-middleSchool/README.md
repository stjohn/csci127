# bridgeUp-STEM-middleSchool
Repository for BridgeUp: STEM program, middle school programs
